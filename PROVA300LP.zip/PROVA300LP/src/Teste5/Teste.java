package Teste5;

public class Teste {

	 public static void main(String[] args) {
	        int x[] = {1,2,3,4,5,6,7};
	        
	        int i = x.length;
	        while (i >= 1) {
	            System.out.print(x[i]);
	            i--;
	        }
	    }
	}