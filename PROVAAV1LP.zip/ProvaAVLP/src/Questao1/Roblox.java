package Questao1;

import java.util.Scanner;

public class Roblox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ler = new Scanner (System.in);
		int azul[] = new int[10];
		int vermelho[] = new int[10];
		int verde[] = new int[10];
		azul[i]= entrada.nextInt();	
		vermelho[i]= entrada.nextInt();	
		verde[i]= entrada.nextInt();	
	}
	for(int i=0; i<10; i++){
		System.out.println("Digite uma chave para entrada de uma porta:");
	}
		for(int j=0; j<9; j++){
			if() {
		System.out.println("Ir para a porta Azul" + azul);
		azul[i] = ler.next();
		System.out.println("Ir para a porta Vermelha" + vermelho);
		vermelho[i] = ler.next();
		System.out.println("Ir para a porta Verde" + verde);
		verde[i] = ler.next();
		System.out.println("Procure novamente");
		next();
	
	}

}
