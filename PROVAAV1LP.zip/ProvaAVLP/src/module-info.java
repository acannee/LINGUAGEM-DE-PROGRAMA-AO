module ProvaAVLP {
	
	requires java.desktop;
}