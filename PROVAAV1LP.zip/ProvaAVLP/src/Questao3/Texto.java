package Questao3;

import java.util.Scanner;
import java.util.Random;

public class Random {

	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		Random ler = new Random ();
		
		int numVogal = 0;
		String numFrase = 0;
		String numPalavras = 0;
		String numVogais = 0;
		String numConsoantes= 0;
		int frase;
		
		System.out.println("Digite uma frase: ");
		
		frase = entrada.nextLine();
		linha = linha.toLowerCase()
		//converter tudo para maiusculo para simplificar a busca
		frase = frase.toUpperCase();
		String vogais="";
		String frase="";
		String palavras="";;
		String Consoantes="";
		char c;
		for (int i = 0; i = 'a' && ch = '0' && ch <= '9') ( ++digits; ){
			
			c=frase.chatAt(i);
			consoantes=consoantes+Character.toString(c);
			System.out.println(consoantes);
		}
		for(int i=0; i < frase.length(); i++)
			{
				c=frase.charAt(i);
				if(c == 'A' || c == 'E' || c =='I' || c == 'O' || c == 'U')
				{
					vogais=vogais+Character.toString(c);
					System.out.println(vogais);
				}
			}
				
		if (vogais.contains("A"))
			numVogal ++;				
		if (vogais.contains("E"))
			numVogal ++;
		if (vogais.contains("I"))
			numVogal ++;
		if (vogais.contains("O"))
			numVogal ++;
		if (vogais.contains("U"))
			numVogal ++;
			

		 System.out.println("Na frase \""+frase+"\" temos:\nVogais: "+vogais+"\nConsoantes: "+consoantes+"n\Palavras"+palavras);
		
		

	}

}
