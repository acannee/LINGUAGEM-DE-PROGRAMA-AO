module Pratica5 {
	requires java.desktop;
}