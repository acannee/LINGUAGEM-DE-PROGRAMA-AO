module PraticaLogica4 {
	requires java.desktop;
}