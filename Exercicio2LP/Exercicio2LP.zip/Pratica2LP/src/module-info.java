module Pratica2LP {
}