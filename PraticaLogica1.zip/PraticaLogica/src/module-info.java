module PraticaLogica {
}