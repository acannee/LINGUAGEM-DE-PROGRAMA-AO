module Pratica6LP {
}